package com.codegym.cms.controller;

import org.springframework.stereotype.Controller;

@Controller
public class CustomerController {

}