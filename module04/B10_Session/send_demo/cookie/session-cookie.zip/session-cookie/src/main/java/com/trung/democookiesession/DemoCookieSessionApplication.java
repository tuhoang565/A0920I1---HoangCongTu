package com.trung.democookiesession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoCookieSessionApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoCookieSessionApplication.class, args);
    }

}
