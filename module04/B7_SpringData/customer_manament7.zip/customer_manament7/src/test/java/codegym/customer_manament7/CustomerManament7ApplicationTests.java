package codegym.customer_manament7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerManament7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
