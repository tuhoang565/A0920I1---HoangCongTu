package codegym.customer_manament7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerManament7Application {

	public static void main(String[] args) {
		SpringApplication.run(CustomerManament7Application.class, args);
	}

}
