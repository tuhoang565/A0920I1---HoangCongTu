package com.codegym.demojpa.service;

import com.codegym.demojpa.model.Course;

import java.util.List;

public interface CourseService {
    List<Course> findAllCourse();
}
